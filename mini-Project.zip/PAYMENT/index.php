
<form method="GET" action="pay.php">
    <input type="text" name="name" Placeholder="Name"><br>
    <input type="number" name="phone" Placeholder="Phone Number"><br>
    <input type="email" name="email" Placeholder="Enter Email Address"><br>
    <input type="number" name="total" Placeholder="Enter Amount"><br>
    <input type="text" name="uid" Placeholder="User ID"><br>
    <input type="text" name="tid" Placeholder="Transaction ID or TEMP"><br>
    <button type="submit">Pay</button>
</form>