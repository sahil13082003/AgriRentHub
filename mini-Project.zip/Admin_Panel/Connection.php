<?php
$con=mysqli_connect("localhost","root","","farmer");

if(mysqli_connect_error())
{
    echo "Cannot Connect";
}

?>